import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/excuse.dart';

class StorageService {
  static const String _favoritesKey = 'favorites';
  static const String _dailyCountKey = 'daily_count';
  static const String _dailyDateKey = 'daily_date';
  static const String _isProKey = 'is_pro';
  static const String _themeKey = 'theme_mode';
  static const int _dailyLimit = 5;

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // ─── Daily limit ────────────────────────────────────
  Future<bool> canGenerate() async {
    final isPro = _prefs?.getBool(_isProKey) ?? false;
    if (isPro) return true;
    await _resetDailyCountIfNeeded();
    final count = _prefs?.getInt(_dailyCountKey) ?? 0;
    return count < _dailyLimit;
  }

  Future<int> getRemainingGenerations() async {
    final isPro = _prefs?.getBool(_isProKey) ?? false;
    if (isPro) return 9999;
    await _resetDailyCountIfNeeded();
    final count = _prefs?.getInt(_dailyCountKey) ?? 0;
    return (_dailyLimit - count).clamp(0, _dailyLimit);
  }

  Future<void> incrementDailyCount() async {
    await _resetDailyCountIfNeeded();
    final count = (_prefs?.getInt(_dailyCountKey) ?? 0) + 1;
    await _prefs?.setInt(_dailyCountKey, count);
  }

  Future<void> _resetDailyCountIfNeeded() async {
    final today = DateTime.now().toIso8601String().substring(0, 10);
    final stored = _prefs?.getString(_dailyDateKey) ?? '';
    if (stored != today) {
      await _prefs?.setString(_dailyDateKey, today);
      await _prefs?.setInt(_dailyCountKey, 0);
    }
  }

  // ─── Favorites ────────────────────────────────────
  List<Excuse> getFavorites() {
    final raw = _prefs?.getStringList(_favoritesKey) ?? [];
    return raw.map((e) => Excuse.fromJson(jsonDecode(e))).toList();
  }

  Future<void> saveFavorite(Excuse excuse) async {
    final favs = getFavorites();
    if (!favs.any((e) => e.id == excuse.id)) {
      favs.add(excuse..isFavorite = true);
      await _prefs?.setStringList(
          _favoritesKey, favs.map((e) => jsonEncode(e.toJson())).toList());
    }
  }

  Future<void> removeFavorite(String id) async {
    final favs = getFavorites();
    favs.removeWhere((e) => e.id == id);
    await _prefs?.setStringList(
        _favoritesKey, favs.map((e) => jsonEncode(e.toJson())).toList());
  }

  bool isFavorite(String id) {
    return getFavorites().any((e) => e.id == id);
  }

  // ─── Pro ────────────────────────────────────
  bool get isPro => _prefs?.getBool(_isProKey) ?? false;

  Future<void> setPro(bool value) async {
    await _prefs?.setBool(_isProKey, value);
  }

  // ─── Theme ────────────────────────────────────
  bool get isDarkMode => _prefs?.getBool(_themeKey) ?? false;

  Future<void> setDarkMode(bool value) async {
    await _prefs?.setBool(_themeKey, value);
  }
}
