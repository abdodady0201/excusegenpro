import 'dart:math';
import '../models/excuse.dart';

class ExcuseService {
  static final Map<String, Map<String, List<String>>> _excuses = {
    'Work': {
      'Formal': [
        "I regret to inform you that I am unable to attend today's meeting due to an unforeseen technical issue with my primary workstation that requires immediate IT intervention.",
        "Please accept my sincerest apologies for missing the deadline. I encountered an unexpected critical dependency failure in our upstream systems that required my full attention.",
        "I must respectfully decline today's assignment. Upon reviewing the project parameters, I've identified several compliance-related concerns that necessitate legal review before proceeding.",
        "I'm afraid I won't be able to submit the report on time. A critical data integrity issue was discovered in our analytics pipeline that I've been tasked with resolving immediately.",
        "I write to formally notify you of my absence today due to an unavoidable infrastructure maintenance emergency that required my immediate on-site presence.",
      ],
      'Funny': [
        "My dog ate my laptop. Yes, really. He mistook it for a very expensive chew toy and now we're both in trouble.",
        "I can't make it to work today because I accidentally scheduled a dentist appointment, a tire rotation, and an existential crisis all for the same morning.",
        "My alarm didn't go off because I was so stressed about work that I dreamed I was already at work, so technically I showed up... just in a different dimension.",
        "I'll be late because I got stuck in an elevator. No wait, I was too lazy to use the elevator and the stairs looked really long from the bottom.",
        "I can't finish this project because my computer is judging me. Every time I type something, it sighs. I need a safer work environment.",
      ],
      'Dramatic': [
        "I CANNOT come in today. My soul has been crushed by the weight of endless spreadsheets and my spirit needs to be rekindled before I can face another pivot table.",
        "The commute nearly claimed my life today — traffic was APOCALYPTIC, a true testament to the fragility of modern civilization and the audacity of rush hour.",
        "I am DESTROYED. The presentation took everything from me. I have nothing left to give until I have experienced at least 14 hours of therapeutic silence.",
        "My computer chose TODAY of all days to betray me. After years of loyal service, it simply refused to boot up, as if it, too, had finally had enough.",
        "I simply cannot write another email. Words have lost all meaning. Language itself feels hollow. I need at least 48 hours to rediscover the joy of communication.",
      ],
      'Smart': [
        "According to Parkinson's Law, work expands to fill the time available. I'm strategically compressing my availability to optimize output quality.",
        "I've applied a cost-benefit analysis to today's tasks and determined that addressing the technical debt first will yield a 340% improvement in downstream efficiency.",
        "My absence today is a calculated investment — research shows that cognitive rest periods of 24 hours increase creative problem-solving capacity by up to 23%.",
        "I'm employing a first-principles thinking approach to restructure my workflow, which temporarily requires stepping back from reactive tasks.",
        "The Eisenhower Matrix clearly indicates today's scheduled meeting falls in the 'Not Urgent, Not Important' quadrant given current project priorities.",
      ],
    },
    'School': {
      'Formal': [
        "I respectfully request an extension on the assignment. I encountered a documented medical situation that prevented me from completing the work within the prescribed timeframe.",
        "Please accept my absence explanation: I was required to attend a family matter of some urgency that could not be rescheduled, as verified by my guardian.",
        "I was unable to submit my homework as the school's online portal experienced technical difficulties that prevented file submission between 10 PM and midnight.",
        "I wish to formally appeal the late penalty. Power fluctuations in my neighborhood resulted in data loss on my computer the evening before the due date.",
        "I must inform you of my late arrival due to an unexpected delay on public transportation caused by service disruptions outside of my control.",
      ],
      'Funny': [
        "I didn't do the homework because I was doing RESEARCH. Specifically, researching what happens when you watch Netflix for 7 hours straight. It's for science.",
        "My homework is technically done — it's just in a format you can't see yet. I call it 'conceptual submission.' Very avant-garde.",
        "I was absent yesterday because I sneezed so hard at 7am that I pulled a muscle and convinced myself I had a rare condition. WebMD agreed with me.",
        "I didn't finish the essay because every time I tried to write the introduction, my brain helpfully decided to think about literally anything else.",
        "I lost my homework. Also my pencil case. Also my binder. Also, possibly, my will to find any of these things. Can I get new copies of everything?",
      ],
      'Dramatic': [
        "I couldn't complete the assignment — I was CONSUMED by an existential question it raised about the nature of knowledge itself and lost track of time.",
        "My absence was a profound spiritual necessity. The weight of midterms had become UNBEARABLE and I needed to reconnect with who I was before academia claimed me.",
        "The test broke me. I studied for HOURS. Days. I gave this exam EVERYTHING and it has returned nothing but confusion and a probable B-minus.",
        "I was present in body yesterday, but my MIND was elsewhere — grappling with the deeper implications of your lecture on a level you probably didn't intend.",
        "I couldn't finish the project. Not because I didn't try, but because I tried SO HARD that I transcended the original scope entirely and got lost in my own ambition.",
      ],
      'Smart': [
        "The assignment's framing contained a logical inconsistency that I spent considerable time attempting to resolve before concluding the prompt needed clarification.",
        "My delayed submission reflects the application of deep processing theory — complex material requires extended incubation periods for genuine comprehension.",
        "I was absent due to optimizing my study approach after reviewing research on spaced repetition, which temporarily disrupted my attendance schedule.",
        "The question asked appears to have multiple valid interpretations. I prepared responses for each scenario, which accounts for the additional time required.",
        "I applied a Socratic method of inquiry to the reading, which led to several recursive questions that required additional primary source research to resolve.",
      ],
    },
    'Friends': {
      'Formal': [
        "I regret to inform you that I will be unable to attend the planned gathering this evening due to prior commitments that have become unavoidable in nature.",
        "Please accept my apologies for the late cancellation. Circumstances beyond my control have necessitated my presence elsewhere this weekend.",
        "I must formally withdraw from tomorrow's plans. I have developed symptoms consistent with a minor respiratory illness and would prefer not to transmit anything.",
        "I am afraid I must decline the invitation. An unexpected family obligation has arisen that requires my immediate and undivided attention.",
        "With great reluctance, I must cancel our scheduled plans. My current workload has reached a critical threshold that demands extended hours this week.",
      ],
      'Funny': [
        "I can't come out tonight. My couch has developed a gravitational field specifically tuned to my body and I legally cannot break free.",
        "I would LOVE to come but my houseplant is giving me the silent treatment and I feel like I shouldn't leave until we've resolved the tension.",
        "I can't make it — I'm in the middle of a very important rewatch of a show I've already seen four times and I'm at a pivotal episode.",
        "I have to cancel because I started a snack and now I'm committed. You understand. Some things you just have to see through to the end.",
        "Sorry, can't come. I tried on my going-out outfit, looked in the mirror, and immediately negotiated a peace treaty with my pajamas instead.",
      ],
      'Dramatic': [
        "I CANNOT join you tonight. I am in the midst of a personal renaissance that requires complete solitude and the uninterrupted company of my own thoughts.",
        "After considerable reflection, I must withdraw. My emotional bandwidth is fully allocated and I fear I would bring nothing but my fatigue to what should be a joyous occasion.",
        "I was truly looking forward to this, but fate has intervened. The universe has conspired — through logistics, weather, and general entropy — to keep me home tonight.",
        "Tonight is simply not my night. I could feel it from the moment I woke up. Some days you fight destiny and some days you let it win gracefully from your sofa.",
        "I must cancel, and it PAINS me. You are extraordinary people who deserve extraordinary presence, and tonight I am merely ordinary. I cannot in good conscience inflict this on you.",
      ],
      'Smart': [
        "I need to decline tonight — I'm in a high-focus work window and interrupting peak cognitive states has statistically measurable negative effects on output.",
        "Based on my current energy levels and the sleep data from last night, I've calculated that socializing tonight would set my recovery back by approximately two days.",
        "I'm practicing intentional social minimalism this week — quality over quantity in interactions leads to deeper connection overall.",
        "I've been applying a social battery management framework, and my current reserves aren't sufficient for the type of environment you're describing.",
        "Time-boxing analysis indicates I need this evening for deep work. I've found that protecting these windows has a compounding positive effect on weekly output.",
      ],
    },
    'Relationship': {
      'Formal': [
        "I wish to formally acknowledge that I forgot our anniversary and have taken appropriate corrective measures including dinner reservations and sincere written apologies.",
        "I regret to inform you that I was incorrect in our earlier discussion. Upon reflection, I have concluded that your position was well-founded and mine was not.",
        "Please accept this notice that I will be arriving home late. The circumstances are entirely work-related and documentation is available upon request.",
        "I formally acknowledge that the thermostat setting was unreasonable. I have adjusted my position and accept full accountability for the temperature dispute.",
        "This serves as official notice that I forgot to do the thing you asked. I am implementing corrective action immediately and have added a reminder system to prevent recurrence.",
      ],
      'Funny': [
        "I wasn't ignoring you, I was just loading. You know how sometimes apps freeze? That's me. I'm a legacy app. Please be patient while I update.",
        "I forgot our anniversary because my love for you is so constant that I stopped tracking it by calendar — it's just always our anniversary in my heart. (Also I forgot.)",
        "I didn't call because I lost track of time, which is something that happens when you're not there because time literally makes no sense without you. Also I was watching something.",
        "I'm sorry for what I said. In my defense, I was hungry, tired, and slightly unhinged, which is basically a separate legal entity from my normal self.",
        "I know I was supposed to do that thing. I thought about doing it three times. Thinking about it counts for something, right? Right?",
      ],
      'Dramatic': [
        "I was LOST without you today. Hours felt like epochs. The silence in your absence was deafening and I simply could not function at full human capacity.",
        "I forgot because I was OVERWHELMED by everything — by work, by life, by the crushing responsibility of being a person, and yes, I know that's not an excuse but it's the truth.",
        "I didn't respond because your message arrived during a moment of profound personal crisis and I needed to compose myself before I could possibly do it justice.",
        "I was late because the world conspired against me at every turn. Traffic, weather, a slow barista — it was as though the universe itself was testing our bond.",
        "I am SORRY. Deeply, completely, cosmically sorry. Words feel insufficient but they are all I have. Please know that my remorse is sincere and extensive.",
      ],
      'Smart': [
        "I missed the event due to a scheduling conflict I failed to anticipate. I'm implementing a shared calendar system to prevent any future synchronization errors.",
        "I was quiet because I was processing. Research on emotional regulation shows that taking time before responding leads to 60% more constructive outcomes.",
        "My approach to this situation was flawed. I've identified the root cause and I'm committed to a systematic improvement with measurable accountability.",
        "I should have communicated earlier. I was optimizing for task completion over relational maintenance, which is clearly the wrong prioritization framework here.",
        "I forgot because I was in a hyperfocused state. I'm now building in external reminders to ensure important shared events aren't deprioritized by cognitive load.",
      ],
    },
  };

  static String generate(String situation, String tone) {
    final list = _excuses[situation]?[tone] ?? [];
    if (list.isEmpty) return "I have a very good reason, I promise.";
    final rng = Random();
    return list[rng.nextInt(list.length)];
  }
}
