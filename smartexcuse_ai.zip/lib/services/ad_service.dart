// Ad Service - Uses test IDs for development
// Replace with real Ad Unit IDs for production
import 'dart:io';

class AdService {
  // Test Ad Unit IDs (safe for development)
  static String get bannerAdUnitId {
    if (Platform.isAndroid) {
      return 'ca-app-pub-3940256099942544/6300978111'; // Test ID
    } else if (Platform.isIOS) {
      return 'ca-app-pub-3940256099942544/2934735716'; // Test ID
    }
    return '';
  }

  static String get interstitialAdUnitId {
    if (Platform.isAndroid) {
      return 'ca-app-pub-3940256099942544/1033173712'; // Test ID
    } else if (Platform.isIOS) {
      return 'ca-app-pub-3940256099942544/4411468910'; // Test ID
    }
    return '';
  }
}

// NOTE: For production, replace test IDs with your real AdMob unit IDs.
// Your App ID goes in AndroidManifest.xml and Info.plist.
// Example AndroidManifest.xml entry:
// <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID"
//            android:value="ca-app-pub-XXXXX~XXXXX"/>
