import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../providers/app_providers.dart';
import '../widgets/shared_widgets.dart';

class ProScreen extends ConsumerWidget {
  const ProScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final isPro = ref.watch(proProvider);

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              const Color(0xFF1E1B4B),
              const Color(0xFF312E81),
              cs.surface,
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            stops: const [0, 0.4, 1],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                // Header
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.close, color: Colors.white),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                ),

                // Crown icon
                Container(
                  width: 90,
                  height: 90,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFF59E0B), Color(0xFFEF4444)],
                    ),
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.amber.withOpacity(0.4),
                        blurRadius: 24,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: const Center(
                    child: Text('👑', style: TextStyle(fontSize: 44)),
                  ),
                )
                    .animate()
                    .scale(duration: 600.ms, curve: Curves.elasticOut)
                    .then()
                    .animate(onPlay: (c) => c.repeat(reverse: true))
                    .moveY(begin: 0, end: -8, duration: 2000.ms, curve: Curves.easeInOut),

                const SizedBox(height: 24),

                if (isPro) ...[
                  const Text(
                    '🎉 You\'re PRO!',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                    ),
                  ).animate().fadeIn(),
                  const SizedBox(height: 12),
                  const Text(
                    'Enjoy unlimited excuses!',
                    style: TextStyle(color: Colors.white70, fontSize: 16),
                  ).animate().fadeIn(delay: 200.ms),
                  const SizedBox(height: 40),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: GradientButton(
                      onPressed: () => Navigator.pop(context),
                      colors: [Colors.green, Colors.teal],
                      child: const Text('Back to App ✓'),
                    ),
                  ),
                ] else ...[
                  const Text(
                    'Upgrade to PRO',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                    ),
                  ).animate().fadeIn(delay: 200.ms),

                  const SizedBox(height: 8),

                  Text(
                    'Unlimited excuses, zero limits',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.7),
                      fontSize: 16,
                    ),
                  ).animate().fadeIn(delay: 300.ms),

                  const SizedBox(height: 36),

                  // Features
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      children: [
                        _FeatureRow(
                          emoji: '♾️',
                          title: 'Unlimited Generations',
                          subtitle: 'No more daily limits, ever',
                        ),
                        _FeatureRow(
                          emoji: '🚫',
                          title: 'Ad-Free Experience',
                          subtitle: 'Clean, distraction-free interface',
                        ),
                        _FeatureRow(
                          emoji: '⚡',
                          title: 'Priority Generation',
                          subtitle: 'Faster excuse generation',
                        ),
                        _FeatureRow(
                          emoji: '🎭',
                          title: 'Exclusive Tones',
                          subtitle: 'Coming soon: Shakespearean, Sarcastic & more',
                        ),
                        _FeatureRow(
                          emoji: '💾',
                          title: 'Unlimited Favorites',
                          subtitle: 'Save as many excuses as you want',
                        ),
                      ],
                    ),
                  ).animate().fadeIn(delay: 400.ms),

                  const SizedBox(height: 36),

                  // Pricing
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      children: [
                        _PricingCard(
                          label: 'Monthly',
                          price: '\$2.99',
                          period: '/month',
                          isPopular: false,
                          onTap: () => _purchase(context, ref, monthly: true),
                        ),
                        const SizedBox(height: 12),
                        _PricingCard(
                          label: 'Yearly',
                          price: '\$14.99',
                          period: '/year',
                          badge: 'Save 58%',
                          isPopular: true,
                          onTap: () => _purchase(context, ref, monthly: false),
                        ),
                      ],
                    ),
                  ).animate().fadeIn(delay: 500.ms),

                  const SizedBox(height: 20),

                  Text(
                    'Cancel anytime • Secure payment',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.5),
                      fontSize: 12,
                    ),
                  ),

                  const SizedBox(height: 16),

                  // For demo: simulate purchase
                  TextButton(
                    onPressed: () => _purchase(context, ref, monthly: true),
                    child: const Text(
                      '✨ Try PRO for Free (Demo)',
                      style: TextStyle(
                        color: Colors.amber,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),

                  const SizedBox(height: 32),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _purchase(BuildContext context, WidgetRef ref,
      {required bool monthly}) async {
    // In production: integrate with in_app_purchase package
    // For demo: simulate successful purchase
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('🎉 Welcome to PRO!'),
        content: const Text(
          'You now have unlimited access to SmartExcuse AI!\n\n'
          'Note: In production, this would connect to your app store subscription.',
        ),
        actions: [
          ElevatedButton(
            onPressed: () async {
              await ref.read(proProvider.notifier).setPro(true);
              if (ctx.mounted) Navigator.pop(ctx);
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('Let\'s Go! 🚀'),
          ),
        ],
      ),
    );
  }
}

class _FeatureRow extends StatelessWidget {
  final String emoji;
  final String title;
  final String subtitle;

  const _FeatureRow({
    required this.emoji,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(child: Text(emoji, style: const TextStyle(fontSize: 20))),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                  ),
                ),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.6),
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          const Icon(Icons.check_circle_rounded, color: Colors.greenAccent, size: 20),
        ],
      ),
    );
  }
}

class _PricingCard extends StatelessWidget {
  final String label;
  final String price;
  final String period;
  final bool isPopular;
  final String? badge;
  final VoidCallback onTap;

  const _PricingCard({
    required this.label,
    required this.price,
    required this.period,
    required this.isPopular,
    required this.onTap,
    this.badge,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: isPopular
              ? const LinearGradient(
                  colors: [Color(0xFFF59E0B), Color(0xFFEF4444)],
                )
              : null,
          color: isPopular ? null : cs.surface,
          borderRadius: BorderRadius.circular(16),
          border: isPopular
              ? null
              : Border.all(color: cs.outline.withOpacity(0.3)),
          boxShadow: isPopular
              ? [
                  BoxShadow(
                    color: Colors.amber.withOpacity(0.3),
                    blurRadius: 20,
                    offset: const Offset(0, 4),
                  )
                ]
              : [],
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        label,
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                          color: isPopular ? Colors.white : cs.onSurface,
                        ),
                      ),
                      if (badge != null) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            badge!,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                  if (isPopular)
                    Text(
                      'Most Popular',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 12,
                      ),
                    ),
                ],
              ),
            ),
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: price,
                    style: TextStyle(
                      color: isPopular ? Colors.white : cs.onSurface,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  TextSpan(
                    text: period,
                    style: TextStyle(
                      color: isPopular
                          ? Colors.white.withOpacity(0.7)
                          : cs.onSurfaceVariant,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
