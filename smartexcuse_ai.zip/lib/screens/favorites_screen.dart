import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:share_plus/share_plus.dart';
import '../providers/app_providers.dart';
import '../widgets/shared_widgets.dart';

class FavoritesScreen extends ConsumerWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    final favorites = ref.watch(favoritesProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Saved Excuses',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
        actions: [
          if (favorites.isNotEmpty)
            TextButton.icon(
              icon: const Icon(Icons.delete_sweep_rounded, size: 18),
              label: const Text('Clear all'),
              style: TextButton.styleFrom(foregroundColor: cs.error),
              onPressed: () => _confirmClearAll(context, ref),
            ),
        ],
      ),
      body: favorites.isEmpty
          ? const EmptyState(
              emoji: '💔',
              title: 'No saved excuses',
              subtitle: 'Tap the heart on any excuse\nto save it here',
            ).animate().fadeIn()
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: favorites.length,
              itemBuilder: (context, index) {
                final excuse = favorites[index];
                return Dismissible(
                  key: Key(excuse.id),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 20),
                    decoration: BoxDecoration(
                      color: cs.errorContainer,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Icon(Icons.delete_rounded, color: cs.error),
                  ),
                  onDismissed: (_) =>
                      ref.read(favoritesProvider.notifier).remove(excuse.id),
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Column(
                      children: [
                        ExcuseCard(
                          text: excuse.text,
                          situation: excuse.situation,
                          tone: excuse.tone,
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            _SmallAction(
                              icon: Icons.copy_rounded,
                              label: 'Copy',
                              onTap: () {
                                Clipboard.setData(
                                    ClipboardData(text: excuse.text));
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: const Text('Copied! ✅'),
                                    backgroundColor: cs.primary,
                                    behavior: SnackBarBehavior.floating,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                  ),
                                );
                              },
                            ),
                            const SizedBox(width: 8),
                            _SmallAction(
                              icon: Icons.share_rounded,
                              label: 'Share',
                              onTap: () => Share.share(
                                '🎭 SmartExcuse AI says:\n\n"${excuse.text}"',
                              ),
                            ),
                            const SizedBox(width: 8),
                            _SmallAction(
                              icon: Icons.delete_rounded,
                              label: 'Remove',
                              color: cs.error,
                              onTap: () => ref
                                  .read(favoritesProvider.notifier)
                                  .remove(excuse.id),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ).animate(delay: Duration(milliseconds: index * 80)).fadeIn().slideX(begin: 0.05);
              },
            ),
    );
  }

  void _confirmClearAll(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear All'),
        content: const Text('Remove all saved excuses?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              final favs = ref.read(favoritesProvider);
              for (final f in favs) {
                ref.read(favoritesProvider.notifier).remove(f.id);
              }
              Navigator.pop(ctx);
            },
            child: Text(
              'Clear All',
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
          ),
        ],
      ),
    );
  }
}

class _SmallAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;

  const _SmallAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: cs.surfaceVariant,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14, color: color ?? cs.primary),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: color ?? cs.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
