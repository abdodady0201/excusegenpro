import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:share_plus/share_plus.dart';
import '../models/excuse.dart';
import '../providers/app_providers.dart';
import '../widgets/shared_widgets.dart';
import 'favorites_screen.dart';
import 'pro_screen.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen>
    with TickerProviderStateMixin {
  late AnimationController _generateController;

  @override
  void initState() {
    super.initState();
    _generateController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
  }

  @override
  void dispose() {
    _generateController.dispose();
    super.dispose();
  }

  Future<void> _generate() async {
    final situation = ref.read(selectedSituationProvider);
    final tone = ref.read(selectedToneProvider);
    _generateController.forward(from: 0);
    await ref.read(excuseProvider.notifier).generate(situation, tone);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final themeMode = ref.watch(themeProvider);
    final isDark = themeMode == ThemeMode.dark;
    final isPro = ref.watch(proProvider);
    final excuseState = ref.watch(excuseProvider);
    final situation = ref.watch(selectedSituationProvider);
    final tone = ref.watch(selectedToneProvider);
    final favorites = ref.watch(favoritesProvider);

    final isLoading = excuseState.status == GenerationStatus.loading;
    final limitReached =
        excuseState.status == GenerationStatus.limitReached && !isPro;

    return Scaffold(
      appBar: AppBar(
        title: RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: 'SmartExcuse ',
                style: tt.titleLarge?.copyWith(
                  fontWeight: FontWeight.w900,
                  color: cs.onSurface,
                ),
              ),
              TextSpan(
                text: 'AI',
                style: tt.titleLarge?.copyWith(
                  fontWeight: FontWeight.w900,
                  color: cs.primary,
                ),
              ),
            ],
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(isDark ? Icons.light_mode : Icons.dark_mode),
            onPressed: () =>
                ref.read(themeProvider.notifier).toggle(),
          ),
          IconButton(
            icon: const Icon(Icons.favorite_rounded),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const FavoritesScreen()),
            ),
          ),
          if (!isPro)
            GestureDetector(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ProScreen()),
              ),
              child: Container(
                margin: const EdgeInsets.only(right: 12, top: 8, bottom: 8),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [cs.secondary, cs.tertiary ?? cs.secondary],
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text(
                  'PRO',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 12,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Usage counter
            if (!isPro)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: excuseState.remaining > 1
                      ? cs.primaryContainer.withOpacity(0.5)
                      : cs.errorContainer.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.auto_awesome,
                      size: 16,
                      color: excuseState.remaining > 1
                          ? cs.primary
                          : cs.error,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '${excuseState.remaining} free generations left today',
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: excuseState.remaining > 1
                            ? cs.onPrimaryContainer
                            : cs.onErrorContainer,
                      ),
                    ),
                    const Spacer(),
                    if (excuseState.remaining <= 1)
                      GestureDetector(
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const ProScreen()),
                        ),
                        child: Text(
                          'Get PRO →',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            color: cs.error,
                            fontSize: 12,
                          ),
                        ),
                      ),
                  ],
                ),
              ).animate().fadeIn(duration: 400.ms),

            const SizedBox(height: 28),

            Text(
              'Choose Situation',
              style: tt.titleMedium?.copyWith(fontWeight: FontWeight.w700),
            ).animate().fadeIn(delay: 100.ms),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: Situation.values.map((s) {
                return SituationChip(
                  label: s.label,
                  emoji: s.emoji,
                  selected: situation == s,
                  onTap: () =>
                      ref.read(selectedSituationProvider.notifier).state = s,
                );
              }).toList(),
            ).animate().fadeIn(delay: 150.ms).slideX(begin: -0.05, end: 0),

            const SizedBox(height: 28),

            Text(
              'Choose Tone',
              style: tt.titleMedium?.copyWith(fontWeight: FontWeight.w700),
            ).animate().fadeIn(delay: 200.ms),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: Tone.values.map((t) {
                return SituationChip(
                  label: t.label,
                  emoji: t.emoji,
                  selected: tone == t,
                  onTap: () =>
                      ref.read(selectedToneProvider.notifier).state = t,
                );
              }).toList(),
            ).animate().fadeIn(delay: 250.ms).slideX(begin: -0.05, end: 0),

            const SizedBox(height: 36),

            // Generate Button
            Center(
              child: limitReached
                  ? Column(
                      children: [
                        const Icon(Icons.lock_rounded, size: 40, color: Colors.amber),
                        const SizedBox(height: 12),
                        const Text(
                          "Daily limit reached!",
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                        ),
                        const SizedBox(height: 8),
                        GradientButton(
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const ProScreen()),
                          ),
                          colors: [Colors.amber, Colors.orange],
                          child: const Text("Upgrade to PRO ✨"),
                        ),
                      ],
                    )
                  : GradientButton(
                      onPressed: isLoading ? null : _generate,
                      isLoading: isLoading,
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.auto_awesome, color: Colors.white, size: 20),
                          SizedBox(width: 8),
                          Text('Generate Excuse'),
                        ],
                      ),
                    ),
            ).animate().fadeIn(delay: 300.ms).scale(
                  begin: const Offset(0.9, 0.9),
                  end: const Offset(1, 1),
                  delay: 300.ms,
                ),

            const SizedBox(height: 32),

            // Result card
            if (excuseState.currentExcuse != null) ...[
              ExcuseCard(
                text: excuseState.currentExcuse!.text,
                situation: excuseState.currentExcuse!.situation,
                tone: excuseState.currentExcuse!.tone,
              )
                  .animate()
                  .fadeIn(duration: 500.ms)
                  .slideY(begin: 0.2, end: 0, duration: 500.ms),

              const SizedBox(height: 16),

              // Action buttons
              Row(
                children: [
                  Expanded(
                    child: _ActionButton(
                      icon: Icons.copy_rounded,
                      label: 'Copy',
                      onTap: () {
                        Clipboard.setData(ClipboardData(
                            text: excuseState.currentExcuse!.text));
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: const Text('Copied to clipboard! ✅'),
                            backgroundColor: cs.primary,
                            behavior: SnackBarBehavior.floating,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _ActionButton(
                      icon: Icons.share_rounded,
                      label: 'Share',
                      onTap: () {
                        Share.share(
                          '🎭 SmartExcuse AI says:\n\n"${excuseState.currentExcuse!.text}"\n\nGenerated with SmartExcuse AI',
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Consumer(builder: (context, ref, _) {
                      final isFav = ref
                          .watch(favoritesProvider.notifier)
                          .isFavorite(excuseState.currentExcuse!.id);
                      return _ActionButton(
                        icon: isFav
                            ? Icons.favorite_rounded
                            : Icons.favorite_border_rounded,
                        label: isFav ? 'Saved' : 'Save',
                        color: isFav ? Colors.red : null,
                        onTap: () {
                          ref
                              .read(favoritesProvider.notifier)
                              .toggle(excuseState.currentExcuse!);
                        },
                      );
                    }),
                  ),
                ],
              ).animate().fadeIn(delay: 200.ms),

              const SizedBox(height: 20),
            ],

            // Ad placeholder (shown for free users)
            if (!isPro) ...[
              Container(
                width: double.infinity,
                height: 60,
                decoration: BoxDecoration(
                  color: cs.surfaceVariant.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: cs.outline.withOpacity(0.3),
                    style: BorderStyle.solid,
                  ),
                ),
                child: Center(
                  child: Text(
                    '📢 Advertisement — Upgrade to PRO to remove ads',
                    style: TextStyle(
                      color: cs.onSurfaceVariant,
                      fontSize: 12,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ],
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;

  const _ActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: cs.surfaceVariant,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          children: [
            Icon(icon, color: color ?? cs.primary, size: 22),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: color ?? cs.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
