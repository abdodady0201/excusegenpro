import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/excuse.dart';
import '../services/storage_service.dart';
import '../services/excuse_service.dart';

// ─── Storage Provider ────────────────────────────────────
final storageServiceProvider = Provider<StorageService>((ref) {
  return StorageService();
});

// ─── Theme Provider ────────────────────────────────────
class ThemeNotifier extends StateNotifier<ThemeMode> {
  final StorageService _storage;

  ThemeNotifier(this._storage)
      : super(_storage.isDarkMode ? ThemeMode.dark : ThemeMode.light);

  void toggle() {
    final isDark = state == ThemeMode.dark;
    state = isDark ? ThemeMode.light : ThemeMode.dark;
    _storage.setDarkMode(!isDark);
  }
}

final themeProvider = StateNotifierProvider<ThemeNotifier, ThemeMode>((ref) {
  final storage = ref.watch(storageServiceProvider);
  return ThemeNotifier(storage);
});

// ─── Pro Provider ────────────────────────────────────
class ProNotifier extends StateNotifier<bool> {
  final StorageService _storage;

  ProNotifier(this._storage) : super(_storage.isPro);

  Future<void> setPro(bool value) async {
    await _storage.setPro(value);
    state = value;
  }
}

final proProvider = StateNotifierProvider<ProNotifier, bool>((ref) {
  final storage = ref.watch(storageServiceProvider);
  return ProNotifier(storage);
});

// ─── Selected Situation ────────────────────────────────────
final selectedSituationProvider = StateProvider<Situation>((ref) => Situation.work);

// ─── Selected Tone ────────────────────────────────────
final selectedToneProvider = StateProvider<Tone>((ref) => Tone.formal);

// ─── Generation state ────────────────────────────────────
enum GenerationStatus { idle, loading, done, limitReached }

class ExcuseState {
  final GenerationStatus status;
  final Excuse? currentExcuse;
  final int remaining;

  const ExcuseState({
    this.status = GenerationStatus.idle,
    this.currentExcuse,
    this.remaining = 5,
  });

  ExcuseState copyWith({
    GenerationStatus? status,
    Excuse? currentExcuse,
    int? remaining,
  }) =>
      ExcuseState(
        status: status ?? this.status,
        currentExcuse: currentExcuse ?? this.currentExcuse,
        remaining: remaining ?? this.remaining,
      );
}

class ExcuseNotifier extends StateNotifier<ExcuseState> {
  final StorageService _storage;

  ExcuseNotifier(this._storage) : super(const ExcuseState()) {
    _loadRemaining();
  }

  Future<void> _loadRemaining() async {
    final remaining = await _storage.getRemainingGenerations();
    state = state.copyWith(remaining: remaining);
  }

  Future<void> generate(Situation situation, Tone tone) async {
    final canGenerate = await _storage.canGenerate();
    if (!canGenerate) {
      state = state.copyWith(status: GenerationStatus.limitReached);
      return;
    }

    state = state.copyWith(status: GenerationStatus.loading);

    // Simulate a short "AI thinking" delay for UX
    await Future.delayed(const Duration(milliseconds: 1200));

    final text = ExcuseService.generate(situation.label, tone.label);
    final excuse = Excuse(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      text: text,
      situation: situation.label,
      tone: tone.label,
      createdAt: DateTime.now(),
    );

    await _storage.incrementDailyCount();
    final remaining = await _storage.getRemainingGenerations();

    state = state.copyWith(
      status: GenerationStatus.done,
      currentExcuse: excuse,
      remaining: remaining,
    );
  }

  void resetStatus() {
    state = state.copyWith(status: GenerationStatus.idle);
  }
}

final excuseProvider = StateNotifierProvider<ExcuseNotifier, ExcuseState>((ref) {
  final storage = ref.watch(storageServiceProvider);
  return ExcuseNotifier(storage);
});

// ─── Favorites ────────────────────────────────────
class FavoritesNotifier extends StateNotifier<List<Excuse>> {
  final StorageService _storage;

  FavoritesNotifier(this._storage) : super(_storage.getFavorites());

  Future<void> toggle(Excuse excuse) async {
    if (_storage.isFavorite(excuse.id)) {
      await _storage.removeFavorite(excuse.id);
    } else {
      await _storage.saveFavorite(excuse);
    }
    state = _storage.getFavorites();
  }

  bool isFavorite(String id) => _storage.isFavorite(id);

  Future<void> remove(String id) async {
    await _storage.removeFavorite(id);
    state = _storage.getFavorites();
  }
}

final favoritesProvider =
    StateNotifierProvider<FavoritesNotifier, List<Excuse>>((ref) {
  final storage = ref.watch(storageServiceProvider);
  return FavoritesNotifier(storage);
});
