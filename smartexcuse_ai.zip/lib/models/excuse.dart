class Excuse {
  final String id;
  final String text;
  final String situation;
  final String tone;
  final DateTime createdAt;
  bool isFavorite;

  Excuse({
    required this.id,
    required this.text,
    required this.situation,
    required this.tone,
    required this.createdAt,
    this.isFavorite = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'text': text,
        'situation': situation,
        'tone': tone,
        'createdAt': createdAt.toIso8601String(),
        'isFavorite': isFavorite,
      };

  factory Excuse.fromJson(Map<String, dynamic> json) => Excuse(
        id: json['id'],
        text: json['text'],
        situation: json['situation'],
        tone: json['tone'],
        createdAt: DateTime.parse(json['createdAt']),
        isFavorite: json['isFavorite'] ?? false,
      );
}

enum Situation {
  work('Work', '💼'),
  school('School', '📚'),
  friends('Friends', '👫'),
  relationship('Relationship', '❤️');

  const Situation(this.label, this.emoji);
  final String label;
  final String emoji;
}

enum Tone {
  formal('Formal', '🎩'),
  funny('Funny', '😂'),
  dramatic('Dramatic', '🎭'),
  smart('Smart', '🧠');

  const Tone(this.label, this.emoji);
  final String label;
  final String emoji;
}
